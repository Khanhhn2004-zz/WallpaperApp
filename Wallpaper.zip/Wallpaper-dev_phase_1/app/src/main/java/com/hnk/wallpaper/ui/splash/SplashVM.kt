package com.hnk.wallpaper.ui.splash

import com.hnk.wallpaper.ui.base.BaseViewModel

class SplashVM : BaseViewModel()