package com.hnk.wallpaper.ui.privicy

import com.hnk.wallpaper.ui.base.BaseViewModel

class PrivacyVM : BaseViewModel()