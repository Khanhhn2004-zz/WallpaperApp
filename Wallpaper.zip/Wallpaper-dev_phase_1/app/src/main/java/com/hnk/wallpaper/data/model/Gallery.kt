package com.hnk.wallpaper.data.model

data class Gallery(
    val id: Long,
    val displayName: String,
    val path: String,
    val size: Long
)