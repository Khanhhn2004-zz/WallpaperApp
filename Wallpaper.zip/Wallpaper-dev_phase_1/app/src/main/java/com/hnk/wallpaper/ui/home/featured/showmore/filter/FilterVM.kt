package com.hnk.wallpaper.ui.home.featured.showmore.filter

import com.hnk.wallpaper.ui.base.BaseViewModel

class FilterVM:BaseViewModel()