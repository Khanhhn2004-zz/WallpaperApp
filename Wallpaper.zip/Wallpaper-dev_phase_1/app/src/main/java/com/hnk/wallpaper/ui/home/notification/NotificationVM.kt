package com.hnk.wallpaper.ui.home.notification

import com.hnk.wallpaper.ui.base.BaseViewModel

class NotificationVM:BaseViewModel() {
}