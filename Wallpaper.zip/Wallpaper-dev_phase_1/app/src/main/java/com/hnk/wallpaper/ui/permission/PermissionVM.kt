package com.hnk.wallpaper.ui.permission

import com.hnk.wallpaper.ui.base.BaseViewModel

class PermissionVM:BaseViewModel()