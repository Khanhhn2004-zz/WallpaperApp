package com.hnk.wallpaper.ui.home

import com.hnk.wallpaper.ui.base.BaseViewModel

class HomeVM:BaseViewModel(){
}